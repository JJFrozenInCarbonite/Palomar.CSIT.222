World Countries list obtained from the following Github repo under the GNU Lesser General Public License
https://github.com/stefangabos/world_countries/blob/master/data/countries/fr/countries.csv